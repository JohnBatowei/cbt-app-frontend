import './styles/footer/footer.css'

const Footer = () => {
    return ( 
      <footer>
        Powered by AriTron ltd | All rights reserved
      </footer>
     );
}
 
export default Footer;