import axios from "axios";

// export default axios.create({
//     baseURL : 'http://localhost:3800/'
// })
export default axios.create({
    baseURL : '/api/api/index'
})