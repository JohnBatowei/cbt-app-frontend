import { PersonBadgeFill } from "react-bootstrap-icons";
import { useAuthContext } from "../../hooks/useAuthContext";
import "./styles/nav/nav.scss";

const Navbar = (props) => {
  const { clickF } = props;
  const { admin } = useAuthContext();
  
  return (
    <div className="nav">
      <div><p>{admin.name || 'Loading...'}</p><p style={{color:'#fdbbe9',fontSize:'10px'}}>{admin.email || 'Loading...'}</p></div>
      <button onClick={clickF}>
        Log out 
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-power" viewBox="0 0 16 16">
          <path d="M7.5 1v7h1V1z"/>
          <path d="M3 8.812a5 5 0 0 1 2.578-4.375l-.485-.874A6 6 0 1 0 11 3.616l-.501.865A5 5 0 1 1 3 8.812"/>
        </svg>
      </button>

    
      {admin && admin.image ? (
        <img crossOrigin="anonymous" src={`${window.location.origin}${admin.image}`} alt="Admin Profile" />
      ) : (
        <PersonBadgeFill style={{ height: "90px", width: "100px" }} />
      )}
    </div>
  );
};

export default Navbar;
