import axios from "axios";

// Set the base URL for all Axios requests
axios.defaults.baseURL = '/api';
// axios.defaults.baseURL = 'http://localhost:3800';

export default axios;
